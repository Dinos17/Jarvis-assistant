import asyncio
import os
from dotenv import load_dotenv
from aria_llm import ARIALLM, DEFAULT_MODE, STREAMING_DEFAULT
from langchain_memory import ARIAMemory

load_dotenv()

async def main():
    user_name = input("Hello! What is your name? ").strip()
    memory = ARIAMemory(user_name)
    llm = ARIALLM()

    mode = DEFAULT_MODE
    streaming = STREAMING_DEFAULT

    print(f"\nARIA online. Type 'exit' to shut me down, {user_name}.\n")

    try:
        while True:
            user_input = input(f"{user_name}: ").strip()
            if user_input.lower() in ("exit", "quit"):
                print("Shutting down ARIA...")
                break

            buffer = []

            def on_token(tok: str):
                buffer.append(tok)
                print(tok, end="", flush=True)

            if streaming:
                print("ARIA: ", end="", flush=True)
                text = await llm.acomplete(
                    user_input,
                    chat_history=[],
                    user_name=user_name,
                    mode=mode,
                    stream=True,
                    on_token=on_token,
                    memory=memory
                )
                print("\n")
            else:
                text = await llm.acomplete(
                    user_input,
                    chat_history=[],
                    user_name=user_name,
                    mode=mode,
                    stream=False,
                    memory=memory
                )
                print(f"ARIA: {text}\n")

            # Add memory (pruning is handled internally)
            memory.add_memory(user_input, text)

    except KeyboardInterrupt:
        print("\nShutting down ARIA...")
    finally:
        await llm.close()

if __name__ == "__main__":
    asyncio.run(main())
