import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain.schema import Document
from typing import List

MEMORY_DIR = "memory_vector"
os.makedirs(MEMORY_DIR, exist_ok=True)
MAX_MEMORY = 200  # Maximum memories before pruning

class ARIAMemory:
    """
    GPT-style long-term memory for ARIA using embeddings + ChromaDB.
    Stores user and assistant messages and retrieves relevant context.
    """

    def __init__(self, user_name: str, top_k: int = 5):
        self.user_name = user_name
        self.top_k = top_k
        # Updated embedding model
        self.embedding_model = SentenceTransformerEmbeddings(
            model_name="sentence-transformers/all-mpnet-base-v2"
        )
        self.vectorstore = Chroma(
            collection_name=f"aria_{user_name}",
            persist_directory=MEMORY_DIR,
            embedding_function=self.embedding_model
        )

    def add_memory(self, user_input: str, assistant_output: str):
        """Add user and AI messages as vector embeddings."""
        docs = [
            Document(page_content=user_input, metadata={"role": "user"}),
            Document(page_content=assistant_output, metadata={"role": "assistant"})
        ]
        self.vectorstore.add_documents(docs)
        self._prune_memory()
        self.vectorstore.persist()

    def retrieve_context(self, query: str) -> List[dict]:
        """Retrieve top-k relevant memories for LLM prompt context."""
        results = self.vectorstore.similarity_search(query, k=self.top_k)
        formatted = [{"role": doc.metadata.get("role", "user"), "content": doc.page_content} for doc in results]
        return formatted

    def _prune_memory(self):
        """Summarize older memories if the collection exceeds MAX_MEMORY."""
        all_docs = self.vectorstore.get(include=["documents"])["documents"]
        if len(all_docs) <= MAX_MEMORY:
            return

        # Simple pruning: summarize first half of documents
        old_docs = all_docs[:len(all_docs)//2]
        summary_content = " ".join(doc.page_content for doc in old_docs)
        summary_doc = Document(page_content=f"[Summarized Memory] {summary_content}", metadata={"role": "system"})
        
        # Remove old docs and add summary
        ids_to_remove = [doc.id for doc in old_docs if hasattr(doc, "id")]
        if ids_to_remove:
            self.vectorstore.delete(ids=ids_to_remove)
        self.vectorstore.add_documents([summary_doc])
