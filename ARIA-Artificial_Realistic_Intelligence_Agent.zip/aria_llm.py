# langchain_memory.py
import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain.schema import Document
from transformers import pipeline

MEMORY_DIR = "memory_vector"
os.makedirs(MEMORY_DIR, exist_ok=True)

# Summarization pipeline for memory pruning
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

# Threshold for max stored memories before summarization
MAX_MEMORIES = 50

class ARIAMemory:
    """
    GPT-style long-term memory for ARIA using embeddings + ChromaDB.
    Stores user and assistant messages and retrieves relevant context.
    Includes memory pruning/summarization and improved embeddings.
    """

    def __init__(self, user_name: str, top_k: int = 5):
        self.user_name = user_name
        self.top_k = top_k
        self.embedding_model = SentenceTransformerEmbeddings(model_name="all-mpnet-base-v2")
        self.vectorstore = Chroma(
            collection_name=f"aria_{user_name}",
            persist_directory=MEMORY_DIR,
            embedding_function=self.embedding_model
        )

    def add_memory(self, user_input: str, assistant_output: str):
        """Add user and AI messages as vector embeddings, prune if necessary."""
        docs = [
            Document(page_content=user_input, metadata={"role": "user"}),
            Document(page_content=assistant_output, metadata={"role": "assistant"})
        ]
        self.vectorstore.add_documents(docs)
        self._prune_if_needed()
        self.vectorstore.persist()

    def _prune_if_needed(self):
        """Summarize older memories if the collection exceeds MAX_MEMORIES."""
        all_docs = self.vectorstore.get()
        if len(all_docs['documents']) > MAX_MEMORIES:
            # Combine oldest documents for summarization
            num_to_summarize = len(all_docs['documents']) // 2
            old_texts = " ".join(doc.page_content for doc in all_docs['documents'][:num_to_summarize])
            summary = summarizer(old_texts, max_length=150, min_length=50, do_sample=False)[0]['summary_text']

            # Remove old documents
            self.vectorstore.delete(ids=[doc.id for doc in all_docs['documents'][:num_to_summarize]])

            # Add summarized memory as a single document
            self.vectorstore.add_documents([Document(page_content=summary, metadata={"role": "summary"})])

    def retrieve_context(self, query: str):
        """Retrieve top-k relevant memories for LLM prompt context."""
        results = self.vectorstore.similarity_search(query, k=self.top_k)
        formatted = []
        for doc in results:
            role = doc.metadata.get("role", "user")
            formatted.append({"role": role, "content": doc.page_content})
        return formatted
